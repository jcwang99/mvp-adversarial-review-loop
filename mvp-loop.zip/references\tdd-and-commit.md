# TDD、修复与提交协议

## 实现代理串行约束

**主代理一次只启动一个实现代理，处理一个 finding 的完整 RED-GREEN-REFACTOR 循环并提交。** 默认不同时启动多个实现代理（算力限制 + git 工作区冲突风险），除非用户明确授权并行且有独立的 git worktree 隔离机制。实现代理完成提交后，主代理再启动下一个实现代理处理下一个 finding。

## 实现代理任务模板

```text
你是唯一的实现代理，只处理 finding [标准 ID，如 R1-F001-SEC]。
现状与证据：[主代理裁决]
必须重现的反例：[完整前提、步骤和期望/实际]
原始反例证据路径：[.review-evidence/round-[N]/R[N]-F[XXX]-[CAT]/ 中的 reproduce.* 或 manual-steps.md]（使用主代理分配的标准 ID）
验收断言：[可测试的行为]
允许改动：[文件/模块]
必须运行：[聚焦测试、回归、静态或安全检查]
禁止：[用户已有改动、无关重构、真实外部写入]

## 运行约定
- 从项目根目录运行，使用项目自身的测试框架、依赖、构建环境
- 项目测试套件使用项目本身的测试配置和数据机制
- 若需要验证修复前后状态对比的临时数据，可放在：.review-evidence/round-[N]/_testdata/impl-[finding-id]/

## 输出约定
- 完整实现报告写入：.review-evidence/round-[N]/[标准 ID]/implementation-result.md
- 必要的完整命令输出写入：.review-evidence/round-[N]/[标准 ID]/output.log
- 返回修复摘要、命令与退出状态摘要、证据路径、提交哈希和未解决问题
- 不要在回复中粘贴完整日志，不要替其他 finding 改代码
```

## RED-GREEN 循环与测试合并

1. **RED**：读取当前 `git status --short`，确认没有新的外部写入。
   - **读取临时测试文件**：检查 `tests/review/reproductions/r{round}_f{num}_{slug}.test.{ext}` 目录（由主代理在 adjudication 阶段从 candidates/ 移动而来）
   - 如果存在可运行的 reproduction 代码，直接运行验证问题存在；若是经批准的手工 finding，执行 `manual-steps.md` 并记录结果
   
   - **将测试合并到项目正式测试套件**：
     - 读取临时 reproduction 文件的测试用例
     - 确定项目中合适的正式测试文件（如 `tests/auth.test.js`、`tests/api_test.py`、`tests/security_test.go` 等）
       - 根据被测模块路径、项目测试组织结构、命名约定临场判断
       - 不同项目情况不同，灵活选择最合适的测试文件
     - **复制**测试用例到正式测试文件（不是移动，临时文件保留）：
       - 调整导入路径、fixture 路径、断言库以符合项目风格
       - 在测试用例中添加注释标注 finding ID（如 `// R1-F001-SEC`、`# R1-F001-SEC`）
       - 合并到现有 describe/suite 块，或创建新的测试分组
     - 临时文件 `tests/review/reproductions/r{round}_f{num}_{slug}.test.{ext}` **保留不删除**（供 verification 阶段使用）
   
   - **运行合并后的测试**：
     - 运行正式测试文件中新合并的测试
     - 保存按预期失败的输出（RED 证据）
   
   - **手工 finding 的处理**：对经确认无法自动化的手工 finding，执行 `manual-steps.md` 并记录环境、操作、结果和证据。回归测试策略：
     - 优先尝试为相邻可测路径添加自动化测试（示例：手工 UI 流程无法自动化，但可测其底层 API 端点或数据层）
     - 若完全无法构造等价自动化测试：
       - 修复提交中说明理由，引用对应 finding 目录中的 manual-steps.md
       - verification-result.md 必须包含修复后的手工复测证据，由验证执行者独立执行步骤
       - 后续回归扫描中，该 finding 需要再次手工检查，或由主代理判断是否跳过并在报告中披露风险
   
   - 没有 RED 证据（自动化失败输出或手工复现记录）不得改实现

2. **GREEN**：实现满足验收断言的最小修复
   - **只修改项目源代码**（不修改测试文件）
   - 沿用项目现有抽象和错误处理，避免顺手升级依赖、重排格式或重写不相关模块
   - 修复后，运行 `npm test`（或项目的测试命令）：
     - 正式测试文件中新合并的测试应该通过
     - 所有原有项目测试也应该通过（确认无回归）
   - 不要为了让测试通过而删除/放宽断言、吞掉错误、跳过权限检查或把真实调用改成无条件 mock

3. **回归检查**：运行项目完整测试套件、类型检查、lint、构建和适用的安全扫描
   - 记录跳过项、失败项和环境限制，不把未执行写成通过
   - 后续 findings 的修复会自动检查之前的修复（因为测试已合并到正式套件）

## 工作区与暂存隔离

共享工作区可能已有用户改动。实现代理必须在开始和提交前各执行一次 `git status --short`，比较基线；只暂存自己为当前 finding 新增或修改的明确路径，例如 `git add -- path/to/test path/to/source`，禁止 `git add -A` 或 `git commit -am`。

### 工作区冲突处理

若同一文件同时含有用户改动和 finding 修复：

1. **实现代理停止并报告**：
   - 在 implementation-result.md 中记录冲突文件列表
   - 标记 `implementation_status: blocked`
   - 返回 `blocker: "user_changes_conflict: [文件列表]"`

2. **主代理判断是否能安全分块**：
   - 使用 `git diff` 检查用户改动的具体位置
   - 使用 `git add -p` 尝试交互式分块暂存
   - **安全分块的条件**：
     - 用户改动和修复改动在不同函数/模块
     - 修改不相邻（至少间隔 5 行）
     - 修改不涉及共享变量或依赖关系
   - **不能安全分块的情况**：
     - 改动在同一函数内
     - 改动涉及相同的变量、类型定义或接口
     - 无法通过 `git add -p` 清晰分离

3. **冲突解决流程**：
   - **能安全分块**：主代理执行分块暂存并提交，更新 finding 状态为 `verification: pending`
   - **不能安全分块**：
     - 更新 finding 状态为 `decision: accepted`, `verification: blocked_by_user_changes`
     - 在 findings-index.md 中记录 `Verification: blocked_by_user_changes`
     - 在 run-state.md 中递增 `verification_blocked_by_user_changes` 计数
     - **不阻止收敛**：这类 finding 在最终报告中单独披露，作为"需要用户手工合并的修复"
     - 在 adjudication.md 中添加字段：`merge_conflict: true`, `user_changes_files: [列表]`

4. **最终报告处理**：
   - 单独章节列出所有 `blocked_by_user_changes` 的 findings
   - 提供手工合并建议：具体文件、冲突位置、推荐修复代码
   - 这些 findings 不计入"未验证"统计，但必须明确披露

提交前至少执行：

```text
git diff --check
git diff --cached --stat
git diff --cached
```

检查秘密、凭据、生成物、日志和大文件没有被暂存。提交信息应包含 finding ID，推荐格式：

```text
fix(review): [ID] concise behavior being corrected
```

**提交内容必须包含**：
1. 源代码修复
2. **项目正式测试文件的修改**（已合并 reproduction 测试用例）；若手工 finding 确认无法自动化，提交记录中说明原因、引用 manual-steps.md 路径，并列出已尝试的相邻可测路径（如有）
3. 必要的配置或依赖更新

**tests/review/ 临时目录不提交到本次修复 commit**：
- 临时测试文件（`tests/review/reproductions/`）保留在工作区，供 verification 阶段使用
- 修复 commit 只包含源代码和正式测试文件的修改
- 整个评审流程结束后，`tests/review/` 目录会被删除

提交成功后返回完整哈希，并更新 run-state.md 与 findings-index.md。若提交钩子失败，修复钩子报告的问题并重新检查差异；不要绕过钩子。若仓库没有 Git 或用户明确要求不提交，返回 commit: unavailable，由主代理在最终报告说明。

## 失败处理

- 聚焦测试没有按预期失败，或手工复现没有观察到预期现象：停止实现，由主代理重新确认 finding。只可撤销实现代理自己刚添加且与用户改动隔离的测试；无法安全区分时保留现场并报告，不能继续猜测实现。
- 修复后测试仍失败：区分代码失败、测试错误和环境故障，保留原始输出；最多做有理由的修正，不以无限重试代替诊断。
- 完整回归失败：暂停后续低优先级 finding，判断是否为回归；必要时创建更高优先级 finding。
- 需要架构改动、破坏性迁移、真实凭据或生产数据：停止并请求主代理确认范围；不得擅自扩大任务。
- 修复无法安全隔离用户改动：不提交，给出最小人工操作建议和阻塞证据。

## 主代理验收清单

只有全部满足才进入修复验证：

- RED 阶段失败证据与原始反例一致。
- **临时测试已复制并合并到项目正式测试文件**；手工 finding 已添加可行的自动化回归测试（或记录无法自动化的理由、已尝试的相邻可测路径、以及修复前后手工执行证据）。
- 修复最小、可读、符合现有契约，且新增测试锁定回归；无法自动化的手工 finding 有明确理由和修复后复测证据。
- 聚焦和回归命令的实际结果已记录；失败/跳过没有被隐藏。
- **提交只包含当前 finding（源代码 + 正式测试文件修改）**，`git diff --check` 通过，用户改动未被覆盖。
- commit、测试、反例和 finding ID 已写入 findings-index.md 与 run-state.md。
- **临时文件 `tests/review/reproductions/` 保留在工作区**（不提交，供 verification 使用）。
